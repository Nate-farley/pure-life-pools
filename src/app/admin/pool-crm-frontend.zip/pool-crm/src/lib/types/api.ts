/**
 * API Types
 *
 * Core types for API responses and server actions.
 * All server actions return ActionResult<T> for consistent handling.
 */

import type { ErrorCode } from '@/lib/utils/errors';

/**
 * Success result from a server action or API call.
 */
export interface SuccessResult<T> {
  success: true;
  data: T;
}

/**
 * Error result from a server action or API call.
 */
export interface ErrorResult {
  success: false;
  error: string;
  code?: ErrorCode;
  details?: Record<string, unknown>;
}

/**
 * Discriminated union type for action results.
 * Use this as the return type for all server actions.
 *
 * @example
 * async function createCustomer(input: CreateCustomerInput): Promise<ActionResult<Customer>> {
 *   try {
 *     const customer = await service.create(input);
 *     return { success: true, data: customer };
 *   } catch (error) {
 *     return { success: false, error: getErrorMessage(error) };
 *   }
 * }
 */
export type ActionResult<T> = SuccessResult<T> | ErrorResult;

/**
 * Type guard to check if result is successful.
 */
export function isSuccess<T>(result: ActionResult<T>): result is SuccessResult<T> {
  return result.success === true;
}

/**
 * Type guard to check if result is an error.
 */
export function isError<T>(result: ActionResult<T>): result is ErrorResult {
  return result.success === false;
}

/**
 * Pagination parameters for list endpoints.
 */
export interface PaginationParams {
  limit?: number;
  cursor?: string | null;
  direction?: 'next' | 'prev';
}

/**
 * Paginated response wrapper.
 */
export interface PaginatedResult<T> {
  items: T[];
  hasMore: boolean;
  nextCursor: string | null;
  prevCursor: string | null;
  total?: number;
}

/**
 * Standard API response envelope.
 */
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: ErrorCode;
    message: string;
    details?: Record<string, unknown>;
  };
  meta: {
    timestamp: string;
    requestId?: string;
  };
}

/**
 * Creates a success response object.
 */
export function successResponse<T>(data: T): SuccessResult<T> {
  return { success: true, data };
}

/**
 * Creates an error response object.
 */
export function errorResponse(
  error: string,
  code?: ErrorCode,
  details?: Record<string, unknown>
): ErrorResult {
  return {
    success: false,
    error,
    code,
    details,
  };
}
