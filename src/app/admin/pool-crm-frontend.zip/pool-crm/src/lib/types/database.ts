/**
 * Database Types
 *
 * TypeScript types matching the database schema.
 * These should be regenerated with `npx supabase gen types typescript`
 * after schema changes.
 */

// ============================================================================
// Core Types
// ============================================================================

export type UUID = string;
export type Timestamp = string; // ISO 8601 format

// ============================================================================
// Admin
// ============================================================================

export interface Admin {
  id: UUID;
  email: string;
  full_name: string;
  created_at: Timestamp;
  updated_at: Timestamp;
}

// ============================================================================
// Customer
// ============================================================================

export interface Customer {
  id: UUID;
  phone: string;
  phone_normalized: string;
  name: string;
  email: string | null;
  source: string | null;
  deleted_at: Timestamp | null;
  created_at: Timestamp;
  updated_at: Timestamp;
  created_by: UUID | null;
}

export interface CustomerWithRelations extends Customer {
  tags?: CustomerTag[];
  properties?: Property[];
  notes_count?: number;
  communications_count?: number;
}

// ============================================================================
// Customer Tags
// ============================================================================

export interface CustomerTag {
  id: UUID;
  name: string;
  color: string;
  created_at: Timestamp;
}

export interface CustomerTagLink {
  customer_id: UUID;
  tag_id: UUID;
  created_at: Timestamp;
}

// ============================================================================
// Customer Notes
// ============================================================================

export interface CustomerNote {
  id: UUID;
  customer_id: UUID;
  content: string;
  created_by: UUID;
  created_at: Timestamp;
  updated_at: Timestamp;
}

export interface CustomerNoteWithAuthor extends CustomerNote {
  author?: Admin;
}

// ============================================================================
// Customer Attachments
// ============================================================================

export interface CustomerAttachment {
  id: UUID;
  customer_id: UUID;
  storage_path: string;
  filename: string;
  content_type: string;
  size_bytes: number;
  note_id: UUID | null;
  uploaded_by: UUID;
  created_at: Timestamp;
}

// ============================================================================
// Communications
// ============================================================================

export type CommunicationType = 'call' | 'text' | 'email';
export type CommunicationDirection = 'inbound' | 'outbound';

export interface Communication {
  id: UUID;
  customer_id: UUID;
  type: CommunicationType;
  direction: CommunicationDirection;
  summary: string;
  occurred_at: Timestamp;
  logged_by: UUID;
  created_at: Timestamp;
}

export interface CommunicationWithAuthor extends Communication {
  author?: Admin;
}

// ============================================================================
// Properties
// ============================================================================

export interface Property {
  id: UUID;
  customer_id: UUID;
  address_line1: string;
  address_line2: string | null;
  city: string;
  state: string;
  zip_code: string;
  gate_code: string | null;
  access_notes: string | null;
  created_at: Timestamp;
  updated_at: Timestamp;
}

export interface PropertyWithPool extends Property {
  pool?: Pool;
}

// ============================================================================
// Pools
// ============================================================================

export type PoolType = 'inground' | 'above_ground' | 'spa' | 'other';
export type PoolSurfaceType = 'plaster' | 'pebble' | 'tile' | 'vinyl' | 'fiberglass';

export interface Pool {
  id: UUID;
  property_id: UUID;
  type: PoolType;
  surface_type: PoolSurfaceType | null;
  length_ft: number | null;
  width_ft: number | null;
  depth_shallow_ft: number | null;
  depth_deep_ft: number | null;
  volume_gallons: number | null;
  equipment_notes: string | null;
  created_at: Timestamp;
  updated_at: Timestamp;
}

// ============================================================================
// Calendar Events
// ============================================================================

export type EventType = 'consultation' | 'estimate_visit' | 'follow_up' | 'other';
export type EventStatus = 'scheduled' | 'completed' | 'canceled';

export interface CalendarEvent {
  id: UUID;
  customer_id: UUID;
  property_id: UUID | null;
  pool_id: UUID | null;
  title: string;
  description: string | null;
  event_type: EventType;
  status: EventStatus;
  start_datetime: Timestamp;
  end_datetime: Timestamp;
  all_day: boolean;
  location_url: string | null;
  reminder_24h_sent: boolean;
  reminder_2h_sent: boolean;
  created_by: UUID;
  version: number;
  created_at: Timestamp;
  updated_at: Timestamp;
}

export interface CalendarEventWithCustomer extends CalendarEvent {
  customer?: Customer;
  property?: Property;
}

// ============================================================================
// Estimates
// ============================================================================

export type EstimateStatus = 'draft' | 'sent' | 'internal_final' | 'converted' | 'declined';

export interface EstimateLineItem {
  id: string;
  description: string;
  quantity: number;
  unit_price_cents: number;
  total_cents: number;
}

export interface Estimate {
  id: UUID;
  estimate_number: string;
  customer_id: UUID;
  pool_id: UUID | null;
  status: EstimateStatus;
  line_items: EstimateLineItem[];
  subtotal_cents: number;
  tax_rate: number;
  tax_amount_cents: number;
  total_cents: number;
  notes: string | null;
  valid_until: string | null; // date only
  created_by: UUID;
  created_at: Timestamp;
  updated_at: Timestamp;
}

export interface EstimateWithCustomer extends Estimate {
  customer?: Customer;
  pool?: Pool;
}

// ============================================================================
// Audit Log
// ============================================================================

export type AuditAction = 'INSERT' | 'UPDATE' | 'DELETE';

export interface AuditLogEntry {
  id: UUID;
  table_name: string;
  record_id: UUID;
  action: AuditAction;
  old_values: Record<string, unknown> | null;
  new_values: Record<string, unknown> | null;
  changed_by: UUID | null;
  created_at: Timestamp;
}
