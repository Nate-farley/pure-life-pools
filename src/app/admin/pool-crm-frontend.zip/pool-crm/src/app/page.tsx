import { redirect } from 'next/navigation';

/**
 * Root Page
 *
 * Redirects to the dashboard.
 * In a full implementation, this would check auth status first.
 */
export default function HomePage() {
  redirect('/dashboard');
}
