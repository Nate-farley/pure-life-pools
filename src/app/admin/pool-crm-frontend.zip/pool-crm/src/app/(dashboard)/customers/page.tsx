import { Metadata } from 'next';
import Link from 'next/link';
import { Plus, Users } from 'lucide-react';

import { Button } from '@/components/ui/button';

export const metadata: Metadata = {
  title: 'Customers',
  description: 'Manage your customer database',
};

/**
 * Customers List Page
 *
 * Displays the customer list with search and filters.
 * For now, shows an empty state to allow testing the create flow.
 */
export default function CustomersPage() {
  // TODO: Fetch customers from database
  const customers: unknown[] = [];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-zinc-900">Customers</h1>
          <p className="text-sm text-zinc-500 mt-1">
            Manage your customer database
          </p>
        </div>
        <Button asChild>
          <Link href="/customers/new">
            <Plus className="w-4 h-4 mr-2" />
            Add Customer
          </Link>
        </Button>
      </div>

      {/* Filters Bar - placeholder for now */}
      <div className="flex items-center gap-3">
        {/* Search and filters will go here */}
      </div>

      {/* Customer List or Empty State */}
      {customers.length === 0 ? (
        <EmptyState />
      ) : (
        <div className="bg-white border border-zinc-200 rounded-lg overflow-hidden">
          {/* Table will go here */}
        </div>
      )}
    </div>
  );
}

/**
 * Empty State Component
 *
 * Shown when there are no customers in the system.
 */
function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center bg-white border border-zinc-200 rounded-lg">
      <div className="w-12 h-12 rounded-full bg-zinc-100 flex items-center justify-center mb-4">
        <Users className="w-6 h-6 text-zinc-400" />
      </div>
      <h3 className="text-sm font-medium text-zinc-900 mb-1">No customers yet</h3>
      <p className="text-sm text-zinc-500 mb-4 max-w-sm">
        Get started by adding your first customer to the system.
      </p>
      <Button asChild>
        <Link href="/customers/new">
          <Plus className="w-4 h-4 mr-2" />
          Add Customer
        </Link>
      </Button>
    </div>
  );
}
