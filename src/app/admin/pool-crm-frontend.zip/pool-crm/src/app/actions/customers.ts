'use server';

/**
 * Customer Server Actions
 *
 * These are the primary API for customer operations from the frontend.
 * Each action validates input with Zod, calls the service layer, and returns ActionResult.
 *
 * Note: Full implementation requires backend service layer (to be implemented).
 * This file provides the action signatures that the frontend needs.
 */

import { revalidatePath } from 'next/cache';
import { createCustomerSchema, type CreateCustomerInput } from '@/lib/validations/customer';
import { normalizePhone } from '@/lib/utils/phone';
import type { Customer } from '@/lib/types/database';
import type { ActionResult } from '@/lib/types/api';

// ============================================================================
// Types for duplicate detection
// ============================================================================

interface DuplicateCustomerResult {
  id: string;
  name: string;
  phone: string;
  email: string | null;
}

// ============================================================================
// Create Customer Action
// ============================================================================

/**
 * Creates a new customer.
 *
 * - Validates input with Zod
 * - Normalizes phone number to E.164 format
 * - Creates customer in database
 * - Returns created customer or error
 */
export async function createCustomer(
  input: CreateCustomerInput
): Promise<ActionResult<Customer>> {
  try {
    // Validate input
    const validationResult = createCustomerSchema.safeParse(input);
    if (!validationResult.success) {
      return {
        success: false,
        error: validationResult.error.errors[0]?.message ?? 'Validation failed',
        code: 'VALIDATION_ERROR',
      };
    }

    const data = validationResult.data;

    // Normalize phone number
    const phoneNormalized = normalizePhone(data.phone);

    // TODO: Implement with Supabase service layer
    // This is a placeholder that simulates the creation
    // In the real implementation, this would:
    // 1. Get authenticated user
    // 2. Call CustomerService.create()
    // 3. Handle database errors

    // Placeholder response for frontend development
    const mockCustomer: Customer = {
      id: crypto.randomUUID(),
      phone: data.phone,
      phone_normalized: phoneNormalized,
      name: data.name,
      email: data.email ?? null,
      source: data.source ?? null,
      deleted_at: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      created_by: null, // Would be admin ID in real implementation
    };

    // Revalidate customers list
    revalidatePath('/customers');

    return {
      success: true,
      data: mockCustomer,
    };
  } catch (error) {
    console.error('Error creating customer:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to create customer',
      code: 'INTERNAL_ERROR',
    };
  }
}

// ============================================================================
// Check Duplicate Phone Action
// ============================================================================

/**
 * Checks if a phone number already exists in the system.
 *
 * - Normalizes phone number
 * - Searches for existing customer
 * - Returns customer data if found, null if not
 */
export async function checkDuplicatePhone(
  phone: string
): Promise<ActionResult<DuplicateCustomerResult | null>> {
  try {
    if (!phone || phone.length < 10) {
      return {
        success: true,
        data: null,
      };
    }

    // Normalize phone number for search
    const phoneNormalized = normalizePhone(phone);

    // TODO: Implement with Supabase service layer
    // This is a placeholder that simulates the duplicate check
    // In the real implementation, this would:
    // 1. Query customers table by phone_normalized
    // 2. Return first match or null

    // Placeholder: Return null (no duplicate) for frontend development
    // In real implementation, this would query the database
    return {
      success: true,
      data: null,
    };
  } catch (error) {
    console.error('Error checking duplicate phone:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to check duplicate',
      code: 'INTERNAL_ERROR',
    };
  }
}

// ============================================================================
// Update Customer Action (placeholder for future implementation)
// ============================================================================

/**
 * Updates an existing customer.
 */
export async function updateCustomer(
  id: string,
  input: Partial<CreateCustomerInput>
): Promise<ActionResult<Customer>> {
  // TODO: Implement with Supabase service layer
  return {
    success: false,
    error: 'Not implemented',
    code: 'INTERNAL_ERROR',
  };
}

// ============================================================================
// Delete Customer Action (placeholder for future implementation)
// ============================================================================

/**
 * Soft deletes a customer.
 */
export async function deleteCustomer(
  id: string
): Promise<ActionResult<{ id: string }>> {
  // TODO: Implement with Supabase service layer
  return {
    success: false,
    error: 'Not implemented',
    code: 'INTERNAL_ERROR',
  };
}

// ============================================================================
// Get Customer Action (placeholder for future implementation)
// ============================================================================

/**
 * Gets a customer by ID.
 */
export async function getCustomer(
  id: string
): Promise<ActionResult<Customer>> {
  // TODO: Implement with Supabase service layer
  return {
    success: false,
    error: 'Not implemented',
    code: 'INTERNAL_ERROR',
  };
}
