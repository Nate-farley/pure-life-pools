import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { Toaster } from 'sonner';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
});

export const metadata: Metadata = {
  title: {
    default: 'Pool CRM',
    template: '%s | Pool CRM',
  },
  description: 'Pool Service Customer Relationship Management System',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="min-h-screen bg-zinc-50 antialiased">
        {children}
        <Toaster
          position="bottom-right"
          toastOptions={{
            className: 'border border-zinc-200',
            duration: 4000,
          }}
        />
      </body>
    </html>
  );
}
