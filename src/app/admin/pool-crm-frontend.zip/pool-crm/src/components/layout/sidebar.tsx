'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Users,
  Calendar,
  FileText,
  Settings,
  LayoutDashboard,
  LogOut,
} from 'lucide-react';
import { cn } from '@/lib/utils';

/**
 * Sidebar Component
 *
 * Fixed sidebar navigation following the design system exactly.
 * Width: 240px (w-60)
 */

interface NavItemProps {
  href: string;
  icon: React.ElementType;
  children: React.ReactNode;
}

function NavItem({ href, icon: Icon, children }: NavItemProps) {
  const pathname = usePathname();
  const isActive = pathname === href || pathname.startsWith(`${href}/`);

  return (
    <Link
      href={href}
      className={cn(
        // Base styles
        `flex items-center gap-3
         px-3 py-2
         text-sm
         rounded-md
         transition-colors duration-150`,
        // Active state
        isActive
          ? 'font-medium text-zinc-900 bg-zinc-100'
          : 'text-zinc-600 hover:bg-zinc-100 hover:text-zinc-900'
      )}
    >
      <Icon className="w-5 h-5" />
      {children}
    </Link>
  );
}

export function Sidebar() {
  return (
    <aside className="fixed inset-y-0 left-0 w-60 bg-white border-r border-zinc-200 z-30 flex flex-col">
      {/* Logo */}
      <div className="h-14 px-4 flex items-center border-b border-zinc-200">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-md bg-blue-600 flex items-center justify-center">
            <span className="text-white font-bold text-sm">PC</span>
          </div>
          <span className="text-lg font-semibold text-zinc-900">Pool CRM</span>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        <NavItem href="/dashboard" icon={LayoutDashboard}>
          Dashboard
        </NavItem>
        <NavItem href="/customers" icon={Users}>
          Customers
        </NavItem>
        <NavItem href="/calendar" icon={Calendar}>
          Calendar
        </NavItem>
        <NavItem href="/estimates" icon={FileText}>
          Estimates
        </NavItem>

        {/* Divider */}
        <div className="my-4 border-t border-zinc-200" />

        <NavItem href="/settings" icon={Settings}>
          Settings
        </NavItem>
      </nav>

      {/* User Menu */}
      <div className="p-3 border-t border-zinc-200">
        <div className="flex items-center gap-3 px-3 py-2">
          <div className="w-8 h-8 rounded-full bg-zinc-100 flex items-center justify-center">
            <span className="text-sm font-medium text-zinc-600">AD</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-zinc-900 truncate">
              Admin User
            </p>
            <p className="text-xs text-zinc-500 truncate">admin@poolcrm.local</p>
          </div>
        </div>
        <button
          className={cn(
            'w-full flex items-center gap-3',
            'px-3 py-2 mt-1',
            'text-sm text-zinc-600',
            'rounded-md',
            'transition-colors duration-150',
            'hover:bg-zinc-100 hover:text-zinc-900'
          )}
        >
          <LogOut className="w-5 h-5" />
          Sign Out
        </button>
      </div>
    </aside>
  );
}
