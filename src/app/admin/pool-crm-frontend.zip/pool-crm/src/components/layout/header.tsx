'use client';

import * as React from 'react';
import { Search, Command } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

/**
 * Header Component
 *
 * Sticky header with global search bar.
 * Height: 56px (h-14)
 */

export function Header() {
  const [searchValue, setSearchValue] = React.useState('');
  const inputRef = React.useRef<HTMLInputElement>(null);

  // Keyboard shortcut: Cmd/Ctrl + K to focus search
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <header className="sticky top-0 z-20 h-14 px-6 bg-white border-b border-zinc-200 flex items-center justify-between">
      {/* Global Search */}
      <div className="flex-1 max-w-md">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-400" />
          <Input
            ref={inputRef}
            type="search"
            placeholder="Search customers..."
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            className="pl-10 pr-12"
          />
          {/* Keyboard shortcut hint */}
          <div className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none">
            <kbd
              className={cn(
                'hidden sm:inline-flex items-center gap-1',
                'px-1.5 py-0.5',
                'text-[10px] font-medium text-zinc-400',
                'bg-zinc-100 border border-zinc-200 rounded'
              )}
            >
              <Command className="w-3 h-3" />K
            </kbd>
          </div>
        </div>
      </div>

      {/* Right side - can add notifications, etc. */}
      <div className="flex items-center gap-4">
        {/* Placeholder for future items */}
      </div>
    </header>
  );
}
