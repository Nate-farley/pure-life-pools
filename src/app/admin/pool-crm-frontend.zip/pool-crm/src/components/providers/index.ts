/**
 * Provider Components
 *
 * This directory contains React context providers:
 * - Supabase client provider (to be implemented with backend)
 * - Toast notification provider (handled by sonner in root layout)
 * - Theme provider (future)
 */

export {};
