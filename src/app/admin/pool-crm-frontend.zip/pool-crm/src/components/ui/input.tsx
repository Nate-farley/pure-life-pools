import * as React from 'react';
import { cn } from '@/lib/utils';

/**
 * Input Component
 *
 * Follows the design system specification exactly.
 * Height: 36px (h-9), with proper focus states.
 */

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  /**
   * Shows error styling when true.
   */
  error?: boolean;
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, error, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          // Base styles
          `w-full h-9 px-3
           bg-white
           text-zinc-900 text-sm placeholder:text-zinc-500
           border rounded-md
           transition-colors duration-150
           focus:outline-none focus:ring-2 focus:ring-offset-0
           disabled:bg-zinc-100 disabled:text-zinc-500 disabled:cursor-not-allowed`,
          // Normal state
          !error && `border-zinc-300 hover:border-zinc-400
                     focus:ring-zinc-950 focus:border-zinc-950`,
          // Error state
          error && `border-red-500 
                    focus:ring-red-500 focus:border-red-500`,
          className
        )}
        ref={ref}
        {...props}
      />
    );
  }
);

Input.displayName = 'Input';

export { Input };
