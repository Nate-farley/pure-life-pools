-- ============================================================================
-- Seed Data: Development Data for Pool Service CRM
-- Run with: npx supabase db reset (includes migrations + seed)
-- Or manually: psql -f seed.sql
-- ============================================================================

-- ============================================================================
-- IMPORTANT: This seed file requires a Supabase Auth user to exist first.
-- You must create the auth user manually or via the Supabase dashboard,
-- then update the admin_user_id below with that user's UUID.
-- ============================================================================

-- Placeholder for admin user ID (replace with actual Supabase Auth user UUID)
-- You can create a user via: Supabase Dashboard > Authentication > Users > Add User
DO $$
DECLARE
    admin_user_id UUID := '00000000-0000-0000-0000-000000000001'; -- REPLACE THIS
    admin_exists BOOLEAN;
    
    -- Customer IDs for reference
    customer1_id UUID;
    customer2_id UUID;
    customer3_id UUID;
    
    -- Property IDs for reference
    property1_id UUID;
    property2_id UUID;
    property3_id UUID;
    
    -- Pool IDs for reference
    pool1_id UUID;
    pool2_id UUID;
    pool3_id UUID;
    
    -- Tag IDs for reference
    tag_vip_id UUID;
    tag_residential_id UUID;
    tag_commercial_id UUID;
    tag_new_lead_id UUID;
BEGIN
    -- Check if admin exists in auth.users (skip if not in test environment)
    SELECT EXISTS(SELECT 1 FROM auth.users WHERE id = admin_user_id) INTO admin_exists;
    
    IF NOT admin_exists THEN
        RAISE NOTICE 'Skipping seed: Admin user % does not exist in auth.users', admin_user_id;
        RAISE NOTICE 'Create the user first via Supabase Dashboard, then update admin_user_id in seed.sql';
        RETURN;
    END IF;

    -- ========================================================================
    -- Admin
    -- ========================================================================
    INSERT INTO admins (id, email, full_name)
    VALUES (admin_user_id, 'admin@poolcrm.local', 'Demo Admin')
    ON CONFLICT (id) DO NOTHING;

    -- ========================================================================
    -- Tags
    -- ========================================================================
    INSERT INTO customer_tags (id, name, color) VALUES
        (gen_random_uuid(), 'VIP', '#8b5cf6'),
        (gen_random_uuid(), 'Residential', '#3b82f6'),
        (gen_random_uuid(), 'Commercial', '#10b981'),
        (gen_random_uuid(), 'New Lead', '#f59e0b')
    RETURNING id INTO tag_vip_id;
    
    -- Get tag IDs
    SELECT id INTO tag_vip_id FROM customer_tags WHERE name = 'VIP';
    SELECT id INTO tag_residential_id FROM customer_tags WHERE name = 'Residential';
    SELECT id INTO tag_commercial_id FROM customer_tags WHERE name = 'Commercial';
    SELECT id INTO tag_new_lead_id FROM customer_tags WHERE name = 'New Lead';

    -- ========================================================================
    -- Customers
    -- ========================================================================
    INSERT INTO customers (id, phone, name, email, source, created_by)
    VALUES 
        (gen_random_uuid(), '(555) 123-4567', 'John Smith', 'john.smith@example.com', 'referral', admin_user_id),
        (gen_random_uuid(), '555-987-6543', 'Sarah Johnson', 'sarah.j@example.com', 'website', admin_user_id),
        (gen_random_uuid(), '5552468135', 'Acme Corp', 'facilities@acme.example.com', 'phone', admin_user_id)
    RETURNING id INTO customer1_id;
    
    -- Get customer IDs
    SELECT id INTO customer1_id FROM customers WHERE name = 'John Smith';
    SELECT id INTO customer2_id FROM customers WHERE name = 'Sarah Johnson';
    SELECT id INTO customer3_id FROM customers WHERE name = 'Acme Corp';

    -- ========================================================================
    -- Customer Tags (assignments)
    -- ========================================================================
    INSERT INTO customer_tag_links (customer_id, tag_id) VALUES
        (customer1_id, tag_vip_id),
        (customer1_id, tag_residential_id),
        (customer2_id, tag_residential_id),
        (customer2_id, tag_new_lead_id),
        (customer3_id, tag_commercial_id);

    -- ========================================================================
    -- Properties
    -- ========================================================================
    INSERT INTO properties (id, customer_id, address_line1, city, state, zip_code, gate_code, access_notes)
    VALUES 
        (gen_random_uuid(), customer1_id, '123 Oak Street', 'Miami', 'FL', '33101', '1234', 'Enter through side gate'),
        (gen_random_uuid(), customer2_id, '456 Palm Avenue', 'Fort Lauderdale', 'FL', '33301', NULL, 'Dogs in backyard - call before arriving'),
        (gen_random_uuid(), customer3_id, '789 Corporate Blvd', 'Boca Raton', 'FL', '33432', '9999#', 'Check in at front desk')
    RETURNING id INTO property1_id;
    
    -- Get property IDs
    SELECT id INTO property1_id FROM properties WHERE address_line1 = '123 Oak Street';
    SELECT id INTO property2_id FROM properties WHERE address_line1 = '456 Palm Avenue';
    SELECT id INTO property3_id FROM properties WHERE address_line1 = '789 Corporate Blvd';

    -- ========================================================================
    -- Pools
    -- ========================================================================
    INSERT INTO pools (id, property_id, type, surface_type, length_ft, width_ft, depth_shallow_ft, depth_deep_ft, volume_gallons, equipment_notes)
    VALUES 
        (gen_random_uuid(), property1_id, 'inground', 'pebble', 32, 16, 3.5, 9, 25000, 'Variable speed pump, salt chlorine generator, solar heating'),
        (gen_random_uuid(), property2_id, 'inground', 'tile', 24, 12, 4, 8, 15000, 'Standard pump, cartridge filter, gas heater'),
        (gen_random_uuid(), property3_id, 'inground', 'plaster', 50, 25, 4, 12, 75000, 'Commercial dual pump system, DE filter, heat pump')
    RETURNING id INTO pool1_id;
    
    -- Get pool IDs
    SELECT id INTO pool1_id FROM pools WHERE property_id = property1_id;
    SELECT id INTO pool2_id FROM pools WHERE property_id = property2_id;
    SELECT id INTO pool3_id FROM pools WHERE property_id = property3_id;

    -- ========================================================================
    -- Customer Notes
    -- ========================================================================
    INSERT INTO customer_notes (customer_id, content, created_by) VALUES
        (customer1_id, 'Long-time customer, very particular about chemical balance. Prefers service on Tuesdays.', admin_user_id),
        (customer1_id, 'Referred us to their neighbor - potential new customer.', admin_user_id),
        (customer2_id, 'Interested in weekly maintenance service. Follow up after estimate.', admin_user_id),
        (customer3_id, 'Contact Maria (facilities manager) for scheduling. Building closes at 6 PM.', admin_user_id);

    -- ========================================================================
    -- Communications
    -- ========================================================================
    INSERT INTO communications (customer_id, type, direction, summary, occurred_at, logged_by) VALUES
        (customer1_id, 'call', 'inbound', 'Customer called to report cloudy water. Scheduled visit for tomorrow.', NOW() - INTERVAL '2 days', admin_user_id),
        (customer1_id, 'call', 'outbound', 'Called to confirm appointment. Customer confirmed availability.', NOW() - INTERVAL '1 day', admin_user_id),
        (customer2_id, 'email', 'inbound', 'Initial inquiry about pool cleaning services from website form.', NOW() - INTERVAL '3 days', admin_user_id),
        (customer2_id, 'call', 'outbound', 'Called to discuss services and schedule estimate visit.', NOW() - INTERVAL '2 days', admin_user_id),
        (customer3_id, 'email', 'outbound', 'Sent monthly maintenance proposal for commercial account.', NOW() - INTERVAL '5 days', admin_user_id);

    -- ========================================================================
    -- Calendar Events
    -- ========================================================================
    INSERT INTO calendar_events (customer_id, property_id, pool_id, title, description, event_type, status, start_datetime, end_datetime, created_by) VALUES
        (customer1_id, property1_id, pool1_id, 'Pool Consultation - Smith', 'Initial consultation to assess pool condition', 'consultation', 'scheduled', NOW() + INTERVAL '1 day' + INTERVAL '10 hours', NOW() + INTERVAL '1 day' + INTERVAL '11 hours', admin_user_id),
        (customer2_id, property2_id, pool2_id, 'Estimate Visit - Johnson', 'On-site visit for maintenance estimate', 'estimate_visit', 'scheduled', NOW() + INTERVAL '2 days' + INTERVAL '14 hours', NOW() + INTERVAL '2 days' + INTERVAL '15 hours', admin_user_id),
        (customer3_id, property3_id, pool3_id, 'Monthly Check-in - Acme Corp', 'Regular monthly maintenance review', 'follow_up', 'scheduled', NOW() + INTERVAL '1 week' + INTERVAL '9 hours', NOW() + INTERVAL '1 week' + INTERVAL '10 hours', admin_user_id),
        (customer1_id, property1_id, pool1_id, 'Previous Service - Smith', 'Completed regular maintenance visit', 'other', 'completed', NOW() - INTERVAL '1 week' + INTERVAL '10 hours', NOW() - INTERVAL '1 week' + INTERVAL '11 hours', admin_user_id);

    -- ========================================================================
    -- Estimates
    -- ========================================================================
    INSERT INTO estimates (customer_id, pool_id, status, line_items, tax_rate, notes, valid_until, created_by) VALUES
        (
            customer1_id, 
            pool1_id, 
            'sent',
            '[
                {"id": "' || gen_random_uuid()::text || '", "description": "Weekly Pool Cleaning Service (4 visits)", "quantity": 4, "unit_price_cents": 15000},
                {"id": "' || gen_random_uuid()::text || '", "description": "Chemical Balance Treatment", "quantity": 1, "unit_price_cents": 7500},
                {"id": "' || gen_random_uuid()::text || '", "description": "Filter Cleaning", "quantity": 1, "unit_price_cents": 5000}
            ]'::jsonb,
            0.07,
            'Monthly maintenance package. Includes all chemicals.',
            (CURRENT_DATE + INTERVAL '30 days')::date,
            admin_user_id
        ),
        (
            customer2_id, 
            pool2_id, 
            'draft',
            '[
                {"id": "' || gen_random_uuid()::text || '", "description": "Initial Pool Assessment", "quantity": 1, "unit_price_cents": 9900},
                {"id": "' || gen_random_uuid()::text || '", "description": "Algae Treatment", "quantity": 1, "unit_price_cents": 12500}
            ]'::jsonb,
            0.07,
            'One-time treatment for algae issue reported.',
            NULL,
            admin_user_id
        ),
        (
            customer3_id, 
            pool3_id, 
            'converted',
            '[
                {"id": "' || gen_random_uuid()::text || '", "description": "Commercial Pool Maintenance (Monthly)", "quantity": 1, "unit_price_cents": 250000},
                {"id": "' || gen_random_uuid()::text || '", "description": "Quarterly Deep Cleaning", "quantity": 1, "unit_price_cents": 75000}
            ]'::jsonb,
            0.07,
            'Annual commercial maintenance contract.',
            (CURRENT_DATE + INTERVAL '90 days')::date,
            admin_user_id
        );

    RAISE NOTICE 'Seed data inserted successfully!';
    RAISE NOTICE 'Created 3 customers, 3 properties, 3 pools, 4 tags, 4 notes, 5 communications, 4 events, 3 estimates';

END $$;
